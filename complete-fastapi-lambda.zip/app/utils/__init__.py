"""
Utility functions for ZapStop
"""
