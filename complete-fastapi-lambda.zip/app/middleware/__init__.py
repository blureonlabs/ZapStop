"""
Middleware for ZapStop
"""
