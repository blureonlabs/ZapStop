#!/usr/bin/env python3
"""
Simple Lambda test without database dependencies
"""

import json
import time
import socket

def handler(event, context):
    """Simple Lambda handler to test VPC connectivity"""
    
    try:
        # Test basic functionality
        result = {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Lambda function is working!',
                'timestamp': time.time(),
                'event': event,
                'context_function_name': context.function_name,
                'context_memory_limit': context.memory_limit_in_mb,
                'context_remaining_time': context.get_remaining_time_in_millis()
            })
        }
        
        # Test network connectivity to database host
        try:
            start_time = time.time()
            ip = socket.gethostbyname('zapstop-db.cxmisq4uo3xv.me-central-1.rds.amazonaws.com')
            dns_time = (time.time() - start_time) * 1000
            
            # Test port connectivity
            start_time = time.time()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            connect_result = sock.connect_ex((ip, 5432))
            sock.close()
            connect_time = (time.time() - start_time) * 1000
            
            result['body'] = json.loads(result['body'])
            result['body']['network_test'] = {
                'database_host': 'zapstop-db.cxmisq4uo3xv.me-central-1.rds.amazonaws.com',
                'resolved_ip': ip,
                'dns_time_ms': round(dns_time, 2),
                'port_5432_open': connect_result == 0,
                'connect_time_ms': round(connect_time, 2)
            }
            result['body'] = json.dumps(result['body'])
            
        except Exception as e:
            result['body'] = json.loads(result['body'])
            result['body']['network_test'] = {
                'error': str(e)
            }
            result['body'] = json.dumps(result['body'])
        
        return result
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Lambda function failed',
                'message': str(e),
                'timestamp': time.time()
            })
        }
