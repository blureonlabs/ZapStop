#!/usr/bin/env python3
"""
Setup AWS RDS database with schema and data from Neon
"""

import json
import os
import sys
import time
import hashlib
import hmac
from datetime import datetime, timedelta
import logging
import urllib.parse
import pg8000

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Set environment variables for AWS RDS
os.environ['DATABASE_URL'] = 'postgresql://zapstop:ZapStop2024!@zapstop-db.cxmisq4uo3xv.me-central-1.rds.amazonaws.com:5432/zapstop'

def get_db_connection():
    """Get database connection with proper error handling"""
    try:
        # Parse the database URL
        url = os.environ['DATABASE_URL']
        parsed = urllib.parse.urlparse(url)
        
        conn = pg8000.connect(
            host=parsed.hostname,
            port=parsed.port,
            database=parsed.path[1:],  # Remove leading slash
            user=parsed.username,
            password=parsed.password,
            ssl_context=True
        )
        return conn
    except Exception as e:
        logger.error(f"Database connection error: {str(e)}")
        return None

def setup_aws_rds():
    """Setup AWS RDS with schema and data from Neon"""
    conn = None
    try:
        conn = get_db_connection()
        if not conn:
            return {"error": "Database connection failed"}
        
        cursor = conn.cursor()
        
        # Read the SQL file
        with open('aws_rds_schema_simple.sql', 'r') as f:
            sql_content = f.read()
        
        # Split by semicolon and execute each statement
        statements = [stmt.strip() for stmt in sql_content.split(';') if stmt.strip()]
        
        logger.info(f"Executing {len(statements)} SQL statements...")
        
        for i, statement in enumerate(statements):
            if statement:
                try:
                    cursor.execute(statement)
                    logger.info(f"✅ Executed statement {i+1}/{len(statements)}")
                except Exception as e:
                    logger.warning(f"⚠️ Statement {i+1} failed: {str(e)}")
                    # Continue with other statements
        
        conn.commit()
        
        # Verify the setup
        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT email, name, role FROM users ORDER BY created_at")
        users = cursor.fetchall()
        
        return {
            "message": "AWS RDS setup completed successfully",
            "user_count": user_count,
            "users": [
                {
                    "email": user[0],
                    "name": user[1], 
                    "role": user[2]
                } for user in users
            ]
        }
        
    except Exception as e:
        logger.error(f"Error setting up AWS RDS: {str(e)}")
        if conn:
            conn.rollback()
        return {"error": str(e)}
    finally:
        if conn:
            conn.close()

def lambda_handler(event, context):
    """AWS Lambda handler to setup AWS RDS"""
    try:
        # Handle CORS preflight
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Access-Control-Max-Age': '86400'
                },
                'body': ''
            }
        
        # Setup AWS RDS
        result = setup_aws_rds()
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(result)
        }
        
    except Exception as e:
        logger.error(f"Lambda handler error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }

if __name__ == "__main__":
    # Test locally
    result = setup_aws_rds()
    print(json.dumps(result, indent=2))
